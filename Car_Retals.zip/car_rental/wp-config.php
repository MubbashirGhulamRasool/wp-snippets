<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'dbcarrtl54' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '3F*zs VB{jxi5#0Yi<Ey!WGa#DdE-<5KRf1wBg%PK9bv}tzNR!<jJz@#Y~]##jL7' );
define( 'SECURE_AUTH_KEY',  '7n0q^*t.J/2G$/[y]k?|j?OOVV<(:4q {JdsSw{vgZp[3 ~Dd;pI+:w}.dOjRJkj' );
define( 'LOGGED_IN_KEY',    'QF7mb(K]`09A$ FQpvrW]a6|sYO(?x+#7?XEs(Z<TY:g#o~4N aJPPIz3p0+m[yC' );
define( 'NONCE_KEY',        'S}3QLVBLsi(9yEfEmyftU~`afI[`G49FdsJ +!F9BNS%$M|Y_==-a nYc%2^9;i,' );
define( 'AUTH_SALT',        'v[qkJ8K%=%wZP~V=}S[NH:fytge)!q%C~8|!dYAgS}.nXq3DWm!7m.VC`P4}l~:]' );
define( 'SECURE_AUTH_SALT', 'biX*lp7Q~=h2$gJx3.J5Yz(,;GU,qv1RNDfXN/NUipTiF*%xA[C>9vJ|c&,y6Xb%' );
define( 'LOGGED_IN_SALT',   'IF83[oRq{.y8,fU4;?X;OPAyJR.Ve;QO)-UN3>x5T:|Ywn8!@Fl;gx4{$A|k7,o<' );
define( 'NONCE_SALT',       'BLm<J lc^:HS,<7BiMpvEn4zQ!LQqJ8=Xbl<O{4gubiu4pPOZjbm=ep/2diXYK#l' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'rcr_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
